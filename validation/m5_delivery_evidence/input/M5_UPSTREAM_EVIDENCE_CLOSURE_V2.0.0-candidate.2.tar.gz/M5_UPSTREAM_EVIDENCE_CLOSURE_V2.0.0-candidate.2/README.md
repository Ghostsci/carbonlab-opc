# M5_UPSTREAM_EVIDENCE_CLOSURE_V2.0.0-candidate.2

`NEW_BASELINE / NOT_A_CONTINUATION`

`PREPARATION_ONLY / REBASELINE / SYNTHETIC_ONLY / NOT_FOR_SUBMISSION`

This closure is a new candidate baseline. It does not recover or replace the
bytes of the seven legacy gaps. It freezes only structured source identities,
outer hashes, new policy candidates, stage verdict mappings, conflict
resolution records, replay controls, and strict permission/stage boundaries.

Restricted source payloads and Holdout/Adversarial truth are not embedded.
Their approved OPC attachment UUIDs and outer SHA-256 values are recorded in
`source-map.json`; display labels are non-authoritative.

## Verify safely

Use the separately supplied byte-identical `safe_extract.py` bootstrap before
extracting anything:

```text
python3 safe_extract.py \
  --archive M5_UPSTREAM_EVIDENCE_CLOSURE_V2.0.0-candidate.2.tar.gz \
  --detached-manifest M5_UPSTREAM_EVIDENCE_CLOSURE_V2.0.0-candidate.2.archive-manifest.json \
  --destination NEW_EMPTY_ROOT \
  --execute
```

The verifier checks the outer hash, audits TAR metadata without landing,
rejects unsafe member types/paths/collisions, extracts regular files with
no-follow semantics, verifies the detached and embedded complete member sets
and every file hash, and only then executes the registered hash-matched
`replay.py` under a minimal environment.

Expected canonical semantic SHA-256: `c826f30228846a9d4d755e8de7ec22a56def689a338a49991caa53e54858924c`.

The six and only six runtime comparison exclusions are exact top-level JSON
pointers: `/generated_at`, `/run_started_at`, `/run_finished_at`,
`/duration_ms`, `/temporary_workdir`, `/process_id`. No wildcard, prefix, or
recursive exclusion exists.

## Candidate state

Independent candidate QA is pending. M5 remains `CHANGES_REQUIRED`; M6 remains
`BLOCKED_BY_M5`. This archive grants no production, real-data, credential,
remote-write, publish, external-LLM, or competition-submission permission.

Rollback removes only reproducible temporary copies. Any submitted candidate,
including a rejected or withdrawn version, must remain read-only with its
archive, hashes, manifests, logs, and verdict.
