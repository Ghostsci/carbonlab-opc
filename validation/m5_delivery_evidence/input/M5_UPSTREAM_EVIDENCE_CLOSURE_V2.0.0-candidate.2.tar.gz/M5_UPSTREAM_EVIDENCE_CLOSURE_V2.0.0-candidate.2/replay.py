#!/usr/bin/env python3
"""Deterministic semantic replay for M5 closure candidate.2."""

from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import os
import re
import stat
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

_CANONICALIZER_PATH = Path(__file__).resolve().parent / "tools" / "canonicalize_json.py"
_CANONICALIZER_SPEC = importlib.util.spec_from_file_location(
    "m5_local_canonicalizer", _CANONICALIZER_PATH
)
if _CANONICALIZER_SPEC is None or _CANONICALIZER_SPEC.loader is None:
    raise RuntimeError("cannot load registered local canonicalizer")
_CANONICALIZER = importlib.util.module_from_spec(_CANONICALIZER_SPEC)
_CANONICALIZER_SPEC.loader.exec_module(_CANONICALIZER)
RUNTIME_EXCLUSION_ALLOWLIST = _CANONICALIZER.RUNTIME_EXCLUSION_ALLOWLIST
CANONICALIZER_VERSION = _CANONICALIZER.VERSION
canonical_sha256 = _CANONICALIZER.canonical_sha256
canonical_text = _CANONICALIZER.canonical_text
exclude_runtime_fields = _CANONICALIZER.exclude_runtime_fields
load_json_file = _CANONICALIZER.load_json_file

VERSION = "m5-closure-replay/2.0.0-candidate.2"
CANDIDATE_VERSION = "M5_UPSTREAM_EVIDENCE_CLOSURE_V2.0.0-candidate.2"
UUID = re.compile(r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$")
HEX64 = re.compile(r"^[0-9a-f]{64}$")
SEMANTIC_DOCUMENTS = (
    "source-map.json",
    "legacy-gaps.json",
    "source-consistency.json",
    "stage-verdicts.json",
    "policies/carbon-field-contract-candidate.json",
    "policies/evidence-policy-candidate.json",
    "policies/permission-matrix-candidate.json",
    "replacement-and-conflict-log.json",
    "review-verdict.json",
    "owner-exit.json",
    "limitations-matrix.json",
    "build-record.json",
)


class ReplayFailure(RuntimeError):
    pass


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def fail(condition: bool, message: str) -> None:
    if not condition:
        raise ReplayFailure(message)


def install_audit_guard(root: Path) -> None:
    resolved_root = root.resolve(strict=True)

    def hook(event: str, args: tuple[Any, ...]) -> None:
        if event.startswith(("socket.", "subprocess.", "os.exec", "os.spawn")) or event == "os.system":
            raise PermissionError(f"replay audit guard blocked: {event}")
        if event == "open" and args:
            candidate = args[0]
            mode = args[1] if len(args) > 1 and isinstance(args[1], str) else "r"
            if any(token in mode for token in ("w", "a", "+", "x")):
                raise PermissionError("replay audit guard blocked file write")
            if isinstance(candidate, (str, bytes, os.PathLike)):
                path = Path(candidate)
                resolved = (resolved_root / path).resolve(strict=False) if not path.is_absolute() else path.resolve(strict=False)
                if resolved != resolved_root and resolved_root not in resolved.parents:
                    raise PermissionError(f"replay audit guard blocked out-of-root read: {resolved}")

    sys.addaudithook(hook)


def verify_manifest(root: Path) -> dict[str, Any]:
    manifest = load_json_file(root / "manifest.json")
    fail(manifest.get("schema_version") == "m5-closure-manifest/2.0", "manifest schema")
    fail(manifest.get("candidate_version") == CANDIDATE_VERSION, "candidate version")
    fail(manifest.get("status") == "NEW_BASELINE / NOT_A_CONTINUATION / PENDING_INDEPENDENT_QA / NOT_EFFECTIVE", "candidate status")
    fail(manifest.get("random_seed") == 20260814, "random seed")
    members = manifest.get("members")
    fail(isinstance(members, list), "manifest members")
    declared = {"manifest.json": manifest.get("self")}
    for item in members:
        fail(isinstance(item, dict), "manifest member object")
        path = item.get("path")
        fail(isinstance(path, str) and path not in declared, "manifest member path")
        fail(item.get("type") == "file", f"manifest member type: {path}")
        fail(isinstance(item.get("size"), int) and item["size"] >= 0, f"manifest member size: {path}")
        fail(isinstance(item.get("sha256"), str) and HEX64.fullmatch(item["sha256"]), f"manifest member hash: {path}")
        declared[path] = item
    fail(manifest.get("member_count") == len(declared), "manifest member_count")
    actual: dict[str, tuple[int, str]] = {}
    for path in root.rglob("*"):
        info = os.lstat(path)
        fail(not stat.S_ISLNK(info.st_mode), f"symlink in closure: {path}")
        if stat.S_ISREG(info.st_mode):
            relative = path.relative_to(root).as_posix()
            actual[relative] = (info.st_size, sha256_file(path))
        else:
            fail(stat.S_ISDIR(info.st_mode), f"non-regular closure object: {path}")
    fail(set(actual) == set(declared), "manifest complete member set")
    for path, item in declared.items():
        if path == "manifest.json":
            continue
        fail(actual[path] == (item["size"], item["sha256"]), f"member hash/size: {path}")
    fail(manifest.get("entrypoint") == "replay.py", "entrypoint")
    tools = manifest.get("tools")
    fail(isinstance(tools, dict), "tool registry")
    for key in ("safe_extractor", "canonicalizer", "replay"):
        tool = tools.get(key)
        fail(isinstance(tool, dict), f"tool registry: {key}")
        path = tool.get("path")
        fail(path in actual and tool.get("sha256") == actual[path][1], f"tool hash: {key}")
    fail(tools["canonicalizer"].get("version") == CANONICALIZER_VERSION, "canonicalizer version")
    fail(tuple(manifest.get("runtime_exclusion_allowlist", [])) == RUNTIME_EXCLUSION_ALLOWLIST, "runtime exclusion allowlist")
    return manifest


def verify_sources(root: Path) -> dict[str, Any]:
    source_map = load_json_file(root / "source-map.json")
    sources = source_map.get("sources")
    fail(isinstance(sources, list) and len(sources) >= 14, "source-map source count")
    source_ids: set[str] = set()
    for source in sources:
        fail(isinstance(source, dict), "source object")
        source_id = source.get("source_id")
        fail(isinstance(source_id, str) and source_id not in source_ids, "source_id unique")
        source_ids.add(source_id)
        fail(isinstance(source.get("issue_uuid"), str) and UUID.fullmatch(source["issue_uuid"]), f"issue UUID: {source_id}")
        fail(isinstance(source.get("comment_id"), str) and UUID.fullmatch(source["comment_id"]), f"comment ID: {source_id}")
        attachment = source.get("attachment_id")
        outer = source.get("outer_sha256")
        if attachment is None:
            fail(outer is None, f"outer hash without attachment: {source_id}")
        else:
            fail(isinstance(attachment, str) and UUID.fullmatch(attachment), f"attachment ID: {source_id}")
            fail(isinstance(outer, str) and HEX64.fullmatch(outer), f"outer hash: {source_id}")
        fail(set(source) >= {"issue_uuid", "comment_id", "attachment_id", "outer_sha256"}, f"canonical identity fields: {source_id}")
    fail(source_map.get("identity_key") == ["issue_uuid", "comment_id", "attachment_id", "outer_sha256"], "source identity key")
    fail(source_map.get("display_hints_non_authoritative") is True, "display hint boundary")
    return source_map


def verify_legacy_gaps(root: Path, source_map: dict[str, Any]) -> dict[str, Any]:
    gaps = load_json_file(root / "legacy-gaps.json")
    items = gaps.get("gaps")
    fail(isinstance(items, list) and len(items) == 7, "legacy gaps 7/7")
    fail([item.get("gap_id") for item in items] == [f"LEGACY-GAP-{index:02d}" for index in range(1, 8)], "legacy gap ordering")
    expected = {
        "LEGACY-GAP-01": ("SRC-M0-OWNER-EXIT", "source-map.json#SRC-M0-OWNER-EXIT", "OWNER_EXIT", "SOURCE_MAP_ENTRY"),
        "LEGACY-GAP-02": ("SRC-M1A-PACKAGE", "source-map.json#SRC-M1A-PACKAGE", "APPROVED_PACKAGE", "SOURCE_MAP_ENTRY"),
        "LEGACY-GAP-03": ("SRC-M1B-EVIDENCE", "source-map.json#SRC-M1B-EVIDENCE", "APPROVED_BUILD_EVIDENCE", "SOURCE_MAP_ENTRY"),
        "LEGACY-GAP-04": ("SRC-M2-PACKAGE", "source-map.json#SRC-M2-PACKAGE", "APPROVED_PACKAGE", "SOURCE_MAP_ENTRY"),
        "LEGACY-GAP-05": ("SRC-M1A-PACKAGE", "policies/carbon-field-contract-candidate.json", "APPROVED_PACKAGE", "DERIVED_CANDIDATE_ARTIFACT"),
        "LEGACY-GAP-06": ("SRC-M1A-PACKAGE", "policies/evidence-policy-candidate.json", "APPROVED_PACKAGE", "DERIVED_CANDIDATE_ARTIFACT"),
        "LEGACY-GAP-07": ("SRC-M1B-CANDIDATE", "policies/permission-matrix-candidate.json", "APPROVED_REFERENCED_PACKAGE", "DERIVED_CANDIDATE_ARTIFACT"),
    }
    source_index = {item["source_id"]: item for item in source_map["sources"]}
    checks: list[dict[str, Any]] = []
    for item in items:
        fail(item.get("classification") == "REBASELINE", f"gap classification: {item.get('gap_id')}")
        fail(item.get("legacy_status") == "LEGACY_EVIDENCE_UNRECOVERABLE / NOT_SUPPLIED_TO_M5", f"gap status: {item.get('gap_id')}")
        fail(item.get("new_baseline_is_continuation") is False, f"gap continuation: {item.get('gap_id')}")
        gap_id = item["gap_id"]
        source_id, path, role, binding = expected[gap_id]
        fail(
            (item.get("new_source_id"), item.get("new_baseline_path"), item.get("new_source_role"), item.get("new_baseline_binding"))
            == (source_id, path, role, binding),
            f"gap exact path/source/role mapping: {gap_id}",
        )
        source = source_index.get(source_id)
        fail(isinstance(source, dict) and source.get("role") == role, f"gap actual source-map role: {gap_id}")
        if binding == "SOURCE_MAP_ENTRY":
            path_matches = path == f"source-map.json#{source_id}"
            target_exists = True
            target_declares_source = True
        else:
            target = root / path
            target_exists = target.is_file()
            target_value = load_json_file(target) if target_exists else {}
            target_declares_source = source_id in target_value.get("source_ids", [])
            path_matches = target_exists and target_declares_source
        fail(path_matches and target_exists and target_declares_source, f"gap path binding: {gap_id}")
        checks.append(
            {
                "gap_id": gap_id,
                "new_baseline_path": path,
                "new_source_id": source_id,
                "declared_source_role": role,
                "actual_source_role": source["role"],
                "new_baseline_binding": binding,
                "path_matches_source_id": path_matches,
                "target_exists": target_exists,
                "target_declares_source": target_declares_source,
                "actual_source_map_entry": source,
                "status": "PASS",
            }
        )
    consistency = load_json_file(root / "source-consistency.json")
    expected_consistency = {
        "schema_version": "m5-source-consistency/1.0",
        "candidate_version": CANDIDATE_VERSION,
        "check_scope": "7/7 legacy-gap new baseline path, source ID, role, and actual source-map entry",
        "checked_count": 7,
        "passed_count": 7,
        "status": "PASS",
        "checks": checks,
    }
    fail(consistency == expected_consistency, "source consistency record exact match")
    return gaps


def verify_policies(root: Path) -> dict[str, Any]:
    field_contract = load_json_file(root / "policies/carbon-field-contract-candidate.json")
    evidence = load_json_file(root / "policies/evidence-policy-candidate.json")
    permission = load_json_file(root / "policies/permission-matrix-candidate.json")
    expected_fields = [
        "operator_name", "installation_name", "product_name", "cn_code",
        "production_route", "period_start", "period_end", "production_output",
        "purchased_electricity",
    ]
    fail(field_contract.get("status") == "NEW_BASELINE_CANDIDATE / PENDING_INDEPENDENT_QA / NOT_EFFECTIVE", "field contract status")
    fail([item.get("code") for item in field_contract.get("fields", [])] == expected_fields, "field contract 9 fields")
    fail(field_contract.get("formal_write_allowed_for_ai") is False, "AI formal write forbidden")
    fail(field_contract.get("confirmation_required_for_all_fields") is True, "human confirmation")
    fail(evidence.get("default_on_mismatch") == "FAIL_CLOSED", "evidence fail closed")
    fail(evidence.get("truth_minimum_disclosure") is True, "truth minimum disclosure")
    fail(evidence.get("independent_review_required") is True, "independent review")
    fail(permission.get("default") == "DENY", "permission default deny")
    forbidden = permission.get("globally_forbidden_actions")
    fail(isinstance(forbidden, list) and set(forbidden) == {
        "real_data_read", "credential_read", "production_access", "remote_write",
        "publish", "competition_submission", "external_llm_call",
    }, "globally forbidden actions")
    fail(permission.get("formal_write_allowed") is False and permission.get("publish_allowed") is False, "write/publish boundary")
    return {"field_contract": field_contract, "evidence": evidence, "permission": permission}


def verify_stage_and_authority(root: Path) -> dict[str, Any]:
    stages = load_json_file(root / "stage-verdicts.json")
    expected = {
        "M0": "PASS_WITH_LIMITATIONS / DONE",
        "M1-A": "APPROVED / DONE",
        "M1-B": "APPROVED / DONE",
        "M2-PREP": "DONE",
        "M2-FORMAL": "ACCEPT / DONE",
        "M5-CLOSURE-CANDIDATE": "PENDING_INDEPENDENT_QA / NOT_EFFECTIVE",
        "M6": "BLOCKED_BY_M5",
    }
    actual = {item.get("stage"): item.get("verdict") for item in stages.get("stages", [])}
    fail(actual == expected, "stage verdict map")
    review = load_json_file(root / "review-verdict.json")
    fail(review.get("design_review_verdict") == "ACCEPT", "design review ACCEPT")
    fail(review.get("candidate_review_verdict") == "PENDING_INDEPENDENT_QA", "candidate review pending")
    owner = load_json_file(root / "owner-exit.json")
    fail(owner.get("candidate_owner_exit") == "PENDING_INDEPENDENT_QA_ACCEPT", "owner exit pending")
    fail(owner.get("self_approval_allowed") is False, "self approval forbidden")
    return {"stages": stages, "review": review, "owner": owner}


def verify_conflicts_and_limits(root: Path) -> dict[str, Any]:
    conflicts = load_json_file(root / "replacement-and-conflict-log.json")
    fail(conflicts.get("unresolved_conflict_count") == 0, "unresolved conflicts")
    records = conflicts.get("records")
    fail(isinstance(records, list) and len(records) >= 9, "replacement records")
    fail(all(record.get("new_baseline_is_continuation") is False for record in records), "replacement continuation boundary")
    limits = load_json_file(root / "limitations-matrix.json")
    fail(limits.get("execution_mode") == "PREPARATION_ONLY / REBASELINE / SYNTHETIC_ONLY / NOT_FOR_SUBMISSION", "execution mode")
    fail(limits.get("m5_status") == "CHANGES_REQUIRED", "M5 remains blocked")
    fail(limits.get("m6_status") == "BLOCKED_BY_M5", "M6 blocked")
    fail(limits.get("truth_payload_included") is False, "truth payload exclusion")
    return {"conflicts": conflicts, "limits": limits}


def semantic_view(root: Path) -> dict[str, Any]:
    return {path: load_json_file(root / path) for path in SEMANTIC_DOCUMENTS}


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--verify-root", type=Path, required=True)
    args = parser.parse_args()
    root = args.verify_root.resolve(strict=True)
    install_audit_guard(root)
    started_ns = time.monotonic_ns()
    started = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
    try:
        manifest = verify_manifest(root)
        source_map = verify_sources(root)
        verify_legacy_gaps(root, source_map)
        verify_policies(root)
        verify_stage_and_authority(root)
        verify_conflicts_and_limits(root)
        semantic_digest = canonical_sha256(semantic_view(root))
        expected = manifest.get("expected_semantic_sha256")
        fail(semantic_digest == expected, "semantic digest")
        finished = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
        result = {
            "candidate_version": CANDIDATE_VERSION,
            "status": "PASS",
            "verified_member_count": manifest["member_count"],
            "legacy_gap_count": 7,
            "legacy_gap_source_consistency_count": 7,
            "source_count": len(load_json_file(root / "source-map.json")["sources"]),
            "semantic_sha256": semantic_digest,
            "runtime_exclusion_allowlist": list(RUNTIME_EXCLUSION_ALLOWLIST),
            "generated_at": finished,
            "run_started_at": started,
            "run_finished_at": finished,
            "duration_ms": (time.monotonic_ns() - started_ns) // 1_000_000,
            "temporary_workdir": str(root),
            "process_id": os.getpid(),
        }
        # Prove the exact exclusion set is accepted and no protected semantic
        # field is removed. The result is not otherwise used for verdict logic.
        exclude_runtime_fields(result, RUNTIME_EXCLUSION_ALLOWLIST)
        print(canonical_text(result))
        return 0
    except Exception as exc:
        print(json.dumps({"status": "FAIL", "reason": str(exc)}, ensure_ascii=False), file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
