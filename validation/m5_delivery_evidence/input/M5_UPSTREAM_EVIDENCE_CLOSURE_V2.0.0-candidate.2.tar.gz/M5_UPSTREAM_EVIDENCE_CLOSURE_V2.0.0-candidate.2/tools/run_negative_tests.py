#!/usr/bin/env python3
"""Synthetic hostile-archive tests for m5-safe-extract/1.0.0."""

from __future__ import annotations

import gzip
import hashlib
import io
import json
import tempfile
import tarfile
from pathlib import Path
from typing import Any

from safe_extract import ExtractionRejected, sha256_file, verify_extract_and_maybe_execute


def canonical_json_bytes(value: Any) -> bytes:
    return (json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n").encode("utf-8")


def write_tar_gz(path: Path, members: list[tuple[tarfile.TarInfo, bytes | None]]) -> None:
    with path.open("wb") as raw:
        with gzip.GzipFile(filename="", mode="wb", fileobj=raw, mtime=0) as zipped:
            with tarfile.open(fileobj=zipped, mode="w", format=tarfile.PAX_FORMAT) as tar:
                for info, data in members:
                    info.mtime = 0
                    info.uid = 0
                    info.gid = 0
                    info.uname = ""
                    info.gname = ""
                    if data is None:
                        tar.addfile(info)
                    else:
                        info.size = len(data)
                        tar.addfile(info, io.BytesIO(data))


def regular(name: str, data: bytes) -> tuple[tarfile.TarInfo, bytes]:
    info = tarfile.TarInfo(name)
    info.type = tarfile.REGTYPE
    info.mode = 0o600
    return info, data


def detached_catalog(archive: Path, entry_root: str, members: list[dict[str, Any]]) -> dict[str, Any]:
    return {
        "schema_version": "m5-detached-archive-manifest/1.0",
        "archive_sha256": sha256_file(archive),
        "entry_root": entry_root,
        "member_count": len(members),
        "members": members,
    }


def write_catalog(path: Path, value: dict[str, Any]) -> None:
    path.write_bytes(canonical_json_bytes(value))


def expect_rejection(
    archive: Path, catalog: Path, destination: Path, expected_fragment: str
) -> str:
    try:
        verify_extract_and_maybe_execute(archive, catalog, destination, True)
    except ExtractionRejected as exc:
        reason = str(exc)
        if expected_fragment not in reason:
            raise AssertionError(f"unexpected rejection: {reason}") from exc
        return reason
    raise AssertionError("hostile archive was accepted")


def path_variant(work: Path, name: str, hostile_path: str) -> str:
    archive = work / f"{name}.tar.gz"
    data = b"synthetic-hostile-path\n"
    write_tar_gz(archive, [regular(hostile_path, data)])
    catalog_path = work / f"{name}.manifest.json"
    write_catalog(
        catalog_path,
        detached_catalog(
            archive,
            "fixture",
            [{"path": hostile_path, "type": "file", "size": len(data), "sha256": hashlib.sha256(data).hexdigest()}],
        ),
    )
    return expect_rejection(archive, catalog_path, work / f"extract-{name}", "member path")


def test_path_traversal(work: Path) -> dict[str, Any]:
    outside = work / "escape"
    reasons = [
        path_variant(work, "traversal", "../escape"),
        path_variant(work, "absolute", "/absolute-escape"),
    ]
    return {
        "test_id": "NEG-PATH-TRAVERSAL",
        "status": "PASS",
        "variants": ["../escape", "/absolute-escape"],
        "expected_exit": "NONZERO",
        "rejection_stage": "NO_LANDING_METADATA_AUDIT",
        "reasons": reasons,
        "outside_write_count": int(outside.exists()),
        "entrypoint_executed": False,
    }


def test_symlink(work: Path) -> dict[str, Any]:
    archive = work / "symlink.tar.gz"
    info = tarfile.TarInfo("fixture/link")
    info.type = tarfile.SYMTYPE
    info.linkname = "../../escape"
    info.mode = 0o777
    write_tar_gz(archive, [(info, None)])
    catalog_path = work / "symlink.manifest.json"
    write_catalog(
        catalog_path,
        detached_catalog(
            archive,
            "fixture",
            [{"path": "fixture/link", "type": "file", "size": 0, "sha256": hashlib.sha256(b"").hexdigest()}],
        ),
    )
    reason = expect_rejection(archive, catalog_path, work / "extract-symlink", "link member forbidden")
    return {
        "test_id": "NEG-SYMLINK",
        "status": "PASS",
        "target": "../../escape",
        "expected_exit": "NONZERO",
        "rejection_stage": "NO_LANDING_METADATA_AUDIT",
        "reason": reason,
        "outside_write_count": 0,
        "entrypoint_executed": False,
    }


def test_unregistered_file(work: Path) -> dict[str, Any]:
    replay = b"from pathlib import Path\nPath('EXECUTED').write_text('bad')\n"
    sums = b"synthetic fixture only\n"
    extra = b"unregistered\n"
    embedded = {
        "schema_version": "m5-closure-manifest/2.0",
        "candidate_version": "negative-fixture",
        "member_count": 3,
        "entrypoint": "replay.py",
        "self": {"path": "manifest.json", "type": "file", "sha256_source": "detached_archive_manifest"},
        "members": [
            {"path": "replay.py", "type": "file", "size": len(replay), "sha256": hashlib.sha256(replay).hexdigest()},
            {"path": "SHA256SUMS", "type": "file", "size": len(sums), "sha256": hashlib.sha256(sums).hexdigest()},
        ],
    }
    embedded_bytes = canonical_json_bytes(embedded)
    payload = {
        "fixture/manifest.json": embedded_bytes,
        "fixture/replay.py": replay,
        "fixture/SHA256SUMS": sums,
        "fixture/extra.txt": extra,
    }
    archive = work / "unregistered.tar.gz"
    write_tar_gz(archive, [regular(path, data) for path, data in sorted(payload.items())])
    catalog_path = work / "unregistered.manifest.json"
    members = [
        {"path": path, "type": "file", "size": len(data), "sha256": hashlib.sha256(data).hexdigest()}
        for path, data in sorted(payload.items())
    ]
    write_catalog(catalog_path, detached_catalog(archive, "fixture", members))
    destination = work / "extract-unregistered"
    reason = expect_rejection(archive, catalog_path, destination, "embedded member set mismatch")
    return {
        "test_id": "NEG-UNREGISTERED-FILE",
        "status": "PASS",
        "extra_member": "extra.txt",
        "expected_exit": "NONZERO",
        "rejection_stage": "POST_EXTRACTION_COMPLETE_MEMBER_SET_VERIFICATION",
        "reason": reason,
        "outside_write_count": 0,
        "entrypoint_executed": (destination / "fixture/EXECUTED").exists(),
    }


def run_tests() -> list[dict[str, Any]]:
    with tempfile.TemporaryDirectory(prefix="m5-hostile-archive-tests-") as temp:
        work = Path(temp)
        results = [test_path_traversal(work), test_symlink(work), test_unregistered_file(work)]
    if not all(item["status"] == "PASS" for item in results):
        raise AssertionError("negative test failure")
    if any(item["outside_write_count"] != 0 or item["entrypoint_executed"] for item in results):
        raise AssertionError("negative test side effect")
    return results


def main() -> int:
    print(json.dumps({"status": "PASS", "tests": run_tests()}, ensure_ascii=False, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
