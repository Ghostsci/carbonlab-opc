#!/usr/bin/env python3
"""Fail-closed TAR verifier/extractor for the M5 evidence closure.

Version: m5-safe-extract/1.0.0

The archive is never passed to extractall(). Metadata is audited without
landing content, then regular-file bytes are copied into a new empty root with
O_NOFOLLOW/O_EXCL semantics. A detached manifest binds the outer archive hash,
the complete archive member set, sizes, and file hashes. The embedded manifest
then binds the closure payload before replay.py may execute.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import posixpath
import re
import shutil
import stat
import subprocess
import sys
import tarfile
import unicodedata
from pathlib import Path, PurePosixPath
from typing import Any, Iterable

VERSION = "m5-safe-extract/1.0.0"
MAX_MEMBER_COUNT = 512
MAX_FILE_BYTES = 16 * 1024 * 1024
MAX_TOTAL_BYTES = 64 * 1024 * 1024
HEX64 = re.compile(r"^[0-9a-f]{64}$")
WINDOWS_DRIVE = re.compile(r"^[A-Za-z]:($|/)")


class ExtractionRejected(RuntimeError):
    """A fail-closed archive or integrity rejection."""


def _duplicate_reject(pairs: Iterable[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise ExtractionRejected(f"duplicate JSON key: {key!r}")
        result[key] = value
    return result


def load_json(path: Path) -> dict[str, Any]:
    try:
        raw = path.read_bytes().decode("utf-8", errors="strict")
        value = json.loads(
            raw,
            object_pairs_hook=_duplicate_reject,
            parse_constant=lambda token: (_ for _ in ()).throw(
                ExtractionRejected(f"non-finite JSON number: {token}")
            ),
        )
    except (OSError, UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ExtractionRejected(f"invalid JSON {path}: {exc}") from exc
    if not isinstance(value, dict):
        raise ExtractionRejected(f"JSON root must be an object: {path}")
    return value


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def normalize_member_name(raw_name: str) -> str:
    if not isinstance(raw_name, str) or not raw_name:
        raise ExtractionRejected("empty or non-string member name")
    if "\x00" in raw_name:
        raise ExtractionRejected(f"NUL in member path: {raw_name!r}")
    if any(0xD800 <= ord(ch) <= 0xDFFF for ch in raw_name):
        raise ExtractionRejected(f"member path is not strict UTF-8: {raw_name!r}")
    unified = raw_name.replace("\\", "/")
    if unified.startswith("/") or unified.startswith("//"):
        raise ExtractionRejected(f"absolute/UNC member path: {raw_name!r}")
    if WINDOWS_DRIVE.match(unified):
        raise ExtractionRejected(f"drive-qualified member path: {raw_name!r}")
    raw_parts = PurePosixPath(unified).parts
    if ".." in raw_parts:
        raise ExtractionRejected(f"parent traversal member path: {raw_name!r}")
    normalized = posixpath.normpath(unified)
    if normalized in ("", "."):
        raise ExtractionRejected(f"empty normalized member path: {raw_name!r}")
    normalized_parts = PurePosixPath(normalized).parts
    if ".." in normalized_parts or normalized.startswith("../"):
        raise ExtractionRejected(f"normalized path escapes root: {raw_name!r}")
    return normalized


def collision_key(path: str) -> str:
    return unicodedata.normalize("NFC", path).casefold()


def audit_archive(archive: Path) -> list[dict[str, Any]]:
    """Audit TAR metadata only; do not create files or directories."""
    audited: list[dict[str, Any]] = []
    seen: dict[str, str] = {}
    file_paths: set[str] = set()
    all_paths: set[str] = set()
    total_bytes = 0
    try:
        with tarfile.open(archive, mode="r:*") as tar:
            members = tar.getmembers()
            if not members or len(members) > MAX_MEMBER_COUNT:
                raise ExtractionRejected(
                    f"member count outside 1..{MAX_MEMBER_COUNT}: {len(members)}"
                )
            for member in members:
                path = normalize_member_name(member.name)
                key = collision_key(path)
                if key in seen:
                    raise ExtractionRejected(
                        f"duplicate/normalized path conflict: {seen[key]!r} vs {path!r}"
                    )
                seen[key] = path
                all_paths.add(path)
                if member.issym() or member.islnk():
                    raise ExtractionRejected(f"link member forbidden: {path}")
                if member.ischr() or member.isblk() or member.isfifo():
                    raise ExtractionRejected(f"device/FIFO member forbidden: {path}")
                if not (member.isfile() or member.isdir()):
                    raise ExtractionRejected(f"non-regular member forbidden: {path}")
                for parent in PurePosixPath(path).parents:
                    parent_text = parent.as_posix()
                    if parent_text == ".":
                        break
                    if parent_text in file_paths:
                        raise ExtractionRejected(
                            f"parent path is a regular file: {parent_text}"
                        )
                member_type = "file" if member.isfile() else "directory"
                size = member.size if member.isfile() else 0
                if size < 0 or size > MAX_FILE_BYTES:
                    raise ExtractionRejected(f"member size rejected: {path}={size}")
                total_bytes += size
                if total_bytes > MAX_TOTAL_BYTES:
                    raise ExtractionRejected("archive uncompressed size limit exceeded")
                if member.isfile():
                    file_paths.add(path)
                audited.append({"path": path, "type": member_type, "size": size})
            for file_path in file_paths:
                prefix = file_path + "/"
                if any(path.startswith(prefix) for path in all_paths):
                    raise ExtractionRejected(f"regular file is a parent path: {file_path}")
    except (tarfile.TarError, OSError) as exc:
        raise ExtractionRejected(f"cannot audit TAR: {exc}") from exc
    return audited


def _catalog_index(catalog: dict[str, Any]) -> dict[str, dict[str, Any]]:
    if catalog.get("schema_version") != "m5-detached-archive-manifest/1.0":
        raise ExtractionRejected("unsupported detached manifest schema")
    members = catalog.get("members")
    if not isinstance(members, list) or catalog.get("member_count") != len(members):
        raise ExtractionRejected("detached member_count mismatch")
    result: dict[str, dict[str, Any]] = {}
    for item in members:
        if not isinstance(item, dict):
            raise ExtractionRejected("detached member must be an object")
        path = normalize_member_name(item.get("path"))
        if path in result:
            raise ExtractionRejected(f"duplicate detached member: {path}")
        if item.get("type") not in ("file", "directory"):
            raise ExtractionRejected(f"invalid detached member type: {path}")
        size = item.get("size")
        if not isinstance(size, int) or size < 0:
            raise ExtractionRejected(f"invalid detached member size: {path}")
        digest = item.get("sha256")
        if item["type"] == "file" and not (
            isinstance(digest, str) and HEX64.fullmatch(digest)
        ):
            raise ExtractionRejected(f"invalid detached SHA-256: {path}")
        if item["type"] == "directory" and digest is not None:
            raise ExtractionRejected(f"directory digest must be null: {path}")
        result[path] = item
    return result


def verify_outer_and_catalog(
    archive: Path, catalog_path: Path, audited: list[dict[str, Any]]
) -> tuple[dict[str, Any], dict[str, dict[str, Any]]]:
    catalog = load_json(catalog_path)
    expected_outer = catalog.get("archive_sha256")
    if not isinstance(expected_outer, str) or not HEX64.fullmatch(expected_outer):
        raise ExtractionRejected("invalid outer archive SHA-256 in detached manifest")
    actual_outer = sha256_file(archive)
    if actual_outer != expected_outer:
        raise ExtractionRejected(
            f"outer archive SHA-256 mismatch: expected {expected_outer}, got {actual_outer}"
        )
    index = _catalog_index(catalog)
    audited_index = {item["path"]: item for item in audited}
    if set(index) != set(audited_index):
        missing = sorted(set(index) - set(audited_index))
        extra = sorted(set(audited_index) - set(index))
        raise ExtractionRejected(f"detached member set mismatch: missing={missing}, extra={extra}")
    for path, item in audited_index.items():
        expected = index[path]
        if item["type"] != expected["type"] or item["size"] != expected["size"]:
            raise ExtractionRejected(f"detached type/size mismatch: {path}")
    return catalog, index


def _ensure_empty_destination(destination: Path) -> None:
    if destination.exists():
        if destination.is_symlink() or not destination.is_dir():
            raise ExtractionRejected("destination must be a real directory")
        if any(destination.iterdir()):
            raise ExtractionRejected("destination must be empty")
    else:
        destination.mkdir(mode=0o700, parents=True)
    if destination.is_symlink():
        raise ExtractionRejected("destination symlink forbidden")


def _safe_parent(root: Path, relative: PurePosixPath) -> Path:
    current = root
    for part in relative.parts:
        current = current / part
        try:
            current.mkdir(mode=0o700)
        except FileExistsError:
            info = os.lstat(current)
            if stat.S_ISLNK(info.st_mode) or not stat.S_ISDIR(info.st_mode):
                raise ExtractionRejected(f"unsafe extraction parent: {current}")
    return current


def extract_verified(
    archive: Path,
    destination: Path,
    audited: list[dict[str, Any]],
    catalog_index: dict[str, dict[str, Any]],
) -> None:
    if not hasattr(os, "O_NOFOLLOW"):
        raise ExtractionRejected("platform lacks required O_NOFOLLOW support")
    _ensure_empty_destination(destination)
    root = destination.resolve(strict=True)
    try:
        with tarfile.open(archive, mode="r:*") as tar:
            tar_by_path = {normalize_member_name(member.name): member for member in tar.getmembers()}
            for item in sorted(audited, key=lambda row: (row["path"].count("/"), row["path"])):
                relative = PurePosixPath(item["path"])
                target = root.joinpath(*relative.parts)
                if item["type"] == "directory":
                    _safe_parent(root, relative)
                    continue
                _safe_parent(root, relative.parent)
                member = tar_by_path[item["path"]]
                source = tar.extractfile(member)
                if source is None:
                    raise ExtractionRejected(f"regular member has no data: {item['path']}")
                flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW
                fd = os.open(target, flags, 0o600)
                digest = hashlib.sha256()
                written = 0
                try:
                    with os.fdopen(fd, "wb", closefd=True) as output:
                        for chunk in iter(lambda: source.read(1024 * 1024), b""):
                            output.write(chunk)
                            digest.update(chunk)
                            written += len(chunk)
                finally:
                    source.close()
                expected = catalog_index[item["path"]]
                if written != expected["size"] or digest.hexdigest() != expected["sha256"]:
                    raise ExtractionRejected(f"extracted size/hash mismatch: {item['path']}")
    except (tarfile.TarError, OSError) as exc:
        if isinstance(exc, ExtractionRejected):
            raise
        raise ExtractionRejected(f"safe extraction failed: {exc}") from exc


def _walk_regular_files(root: Path) -> dict[str, dict[str, Any]]:
    result: dict[str, dict[str, Any]] = {}
    for current, dirnames, filenames in os.walk(root, followlinks=False):
        current_path = Path(current)
        for name in list(dirnames):
            path = current_path / name
            info = os.lstat(path)
            if stat.S_ISLNK(info.st_mode) or not stat.S_ISDIR(info.st_mode):
                raise ExtractionRejected(f"non-directory found in directory set: {path}")
        for name in filenames:
            path = current_path / name
            info = os.lstat(path)
            if stat.S_ISLNK(info.st_mode) or not stat.S_ISREG(info.st_mode):
                raise ExtractionRejected(f"non-regular extracted file: {path}")
            relative = path.relative_to(root).as_posix()
            result[relative] = {
                "path": relative,
                "type": "file",
                "size": info.st_size,
                "sha256": sha256_file(path),
            }
    return result


def verify_embedded_manifest(entry_root: Path) -> tuple[dict[str, Any], str]:
    manifest_path = entry_root / "manifest.json"
    manifest = load_json(manifest_path)
    if manifest.get("schema_version") != "m5-closure-manifest/2.0":
        raise ExtractionRejected("unsupported embedded manifest schema")
    self_entry = manifest.get("self")
    if not isinstance(self_entry, dict) or self_entry.get("path") != "manifest.json":
        raise ExtractionRejected("embedded manifest self registration missing")
    members = manifest.get("members")
    if not isinstance(members, list) or manifest.get("member_count") != len(members) + 1:
        raise ExtractionRejected("embedded member_count mismatch")
    declared: dict[str, dict[str, Any]] = {"manifest.json": self_entry}
    for item in members:
        if not isinstance(item, dict) or item.get("type") != "file":
            raise ExtractionRejected("embedded manifest allows regular files only")
        path = normalize_member_name(item.get("path"))
        digest = item.get("sha256")
        if not isinstance(digest, str) or not HEX64.fullmatch(digest):
            raise ExtractionRejected(f"embedded SHA-256 invalid: {path}")
        if path in declared:
            raise ExtractionRejected(f"duplicate embedded member: {path}")
        declared[path] = item
    actual = _walk_regular_files(entry_root)
    if set(actual) != set(declared):
        missing = sorted(set(declared) - set(actual))
        extra = sorted(set(actual) - set(declared))
        raise ExtractionRejected(f"embedded member set mismatch: missing={missing}, extra={extra}")
    for path, item in declared.items():
        if path == "manifest.json":
            # The detached manifest binds this file to avoid a self-hash cycle.
            continue
        if actual[path]["size"] != item.get("size") or actual[path]["sha256"] != item["sha256"]:
            raise ExtractionRejected(f"embedded member size/hash mismatch: {path}")
    entrypoint = manifest.get("entrypoint")
    if entrypoint != "replay.py" or entrypoint not in declared:
        raise ExtractionRejected("unique replay.py entrypoint is not registered")
    return manifest, actual[entrypoint]["sha256"]


def _snapshot(root: Path) -> dict[str, tuple[int, str]]:
    files = _walk_regular_files(root)
    return {path: (item["size"], item["sha256"]) for path, item in files.items()}


def execute_replay(entry_root: Path, replay_sha256: str) -> subprocess.CompletedProcess[str]:
    replay_path = entry_root / "replay.py"
    if sha256_file(replay_path) != replay_sha256:
        raise ExtractionRejected("replay.py changed before execution")
    before = _snapshot(entry_root)
    environment = {
        "PATH": "",
        "LANG": "C.UTF-8",
        "LC_ALL": "C.UTF-8",
        "PYTHONHASHSEED": "0",
        "PYTHONDONTWRITEBYTECODE": "1",
        "NO_PROXY": "*",
        "no_proxy": "*",
    }
    completed = subprocess.run(
        [sys.executable, "-I", "-B", str(replay_path), "--verify-root", str(entry_root)],
        cwd=entry_root,
        env=environment,
        text=True,
        capture_output=True,
        timeout=60,
        check=False,
    )
    after = _snapshot(entry_root)
    if before != after:
        raise ExtractionRejected("replay.py modified the verified closure")
    if completed.returncode != 0:
        detail = completed.stderr.strip() or completed.stdout.strip()
        raise ExtractionRejected(f"replay.py failed with exit {completed.returncode}: {detail}")
    return completed


def verify_extract_and_maybe_execute(
    archive: Path, detached_manifest: Path, destination: Path, execute: bool
) -> dict[str, Any]:
    audited = audit_archive(archive)
    catalog, catalog_index = verify_outer_and_catalog(archive, detached_manifest, audited)
    extract_verified(archive, destination, audited, catalog_index)
    entry_root_rel = normalize_member_name(catalog.get("entry_root"))
    entry_root = destination.joinpath(*PurePosixPath(entry_root_rel).parts)
    if not entry_root.is_dir() or entry_root.is_symlink():
        raise ExtractionRejected("detached entry_root is missing or unsafe")
    manifest, replay_sha = verify_embedded_manifest(entry_root)
    result: dict[str, Any] = {
        "status": "PASS",
        "outer_sha256": catalog["archive_sha256"],
        "archive_member_count": len(audited),
        "closure_member_count": manifest["member_count"],
        "entrypoint_sha256": replay_sha,
        "executed": False,
    }
    if execute:
        completed = execute_replay(entry_root, replay_sha)
        result["executed"] = True
        result["replay_stdout"] = completed.stdout.strip()
    return result


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--archive", type=Path, required=True)
    parser.add_argument("--detached-manifest", type=Path, required=True)
    parser.add_argument("--destination", type=Path, required=True)
    parser.add_argument("--execute", action="store_true")
    parser.add_argument("--keep-rejected", action="store_true")
    args = parser.parse_args()
    try:
        result = verify_extract_and_maybe_execute(
            args.archive, args.detached_manifest, args.destination, args.execute
        )
    except ExtractionRejected as exc:
        if not args.keep_rejected and args.destination.exists():
            shutil.rmtree(args.destination, ignore_errors=True)
        print(json.dumps({"status": "REJECTED", "reason": str(exc)}, ensure_ascii=False), file=sys.stderr)
        return 2
    print(json.dumps(result, ensure_ascii=False, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
