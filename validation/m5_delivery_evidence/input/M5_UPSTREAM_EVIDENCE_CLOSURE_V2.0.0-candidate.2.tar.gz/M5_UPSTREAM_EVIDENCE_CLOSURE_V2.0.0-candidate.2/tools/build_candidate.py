#!/usr/bin/env python3
"""Build M5_UPSTREAM_EVIDENCE_CLOSURE_V2.0.0-candidate.2.

The generator consumes only approved, locally downloaded OPC attachments and
their frozen hashes. It derives structured policy candidates from G1-A/G1-B
machine records, never from model output. Source payloads containing restricted
truth are hash-referenced and deliberately not copied into the M5 closure.
"""

from __future__ import annotations

import argparse
import gzip
import hashlib
import io
import json
import os
import shutil
import tarfile
from pathlib import Path
from typing import Any

from canonicalize_json import canonical_sha256, canonical_text, load_json_bytes, load_json_file
from run_negative_tests import run_tests
from safe_extract import VERSION as SAFE_EXTRACT_VERSION, audit_archive, sha256_file

CANDIDATE_VERSION = "M5_UPSTREAM_EVIDENCE_CLOSURE_V2.0.0-candidate.2"
ROOT_NAME = CANDIDATE_VERSION
GENERATOR_VERSION = "m5-evidence-closure-generator/2.0.0-candidate.2"
RULE_VERSION = "M5_UPSTREAM_EVIDENCE_REBASELINE_DESIGN_V1.0.1"
RANDOM_SEED = 20260814
BASELINE_REPOSITORY = "https://github.com/Ghostsci/carbonlab-opc.git"
BASELINE_COMMIT = "c4f0b5bab63572dd0b9722be7aa12293fc3fb2b8"
EXECUTION_MODE = "PREPARATION_ONLY / REBASELINE / SYNTHETIC_ONLY / NOT_FOR_SUBMISSION"

EXPECTED_INPUTS = {
    "G1-A-v2.0.0-candidate.4.tar": "afabf7b7f8ff7b5c6366949324de1ff82db0d7d45f2aecfb4bd2b7dc2bb59749",
    "G1-B-v2.0.2-candidate.tar.gz": "743d73b26186454f77ad4098c4cb05267e28738069b0470a2ad2cc14eb193873",
    "G1-B-v2.0.3-build-evidence.json": "59e3373d7fb2c9ace4d4712f26f0e1afc740e45a6aae7a8c6fd138ef93f2fb3d",
    "M2_FORMAL_REFROZEN_PATCH_AND_PYTEST_V4.tar.gz": "bf3948fa2b47e2f11cb8a2651b3059c6ad61943d9313bd7ff2ab37d76384b671",
    "M5_UPSTREAM_EVIDENCE_REBASELINE_DESIGN_V1.0.1.md": "c0b285b90b1c8f11c480eaeb7869c663e7ba66b74f82f75b52bac046e3a1a542",
}

SEMANTIC_DOCUMENTS = (
    "source-map.json",
    "legacy-gaps.json",
    "source-consistency.json",
    "stage-verdicts.json",
    "policies/carbon-field-contract-candidate.json",
    "policies/evidence-policy-candidate.json",
    "policies/permission-matrix-candidate.json",
    "replacement-and-conflict-log.json",
    "review-verdict.json",
    "owner-exit.json",
    "limitations-matrix.json",
    "build-record.json",
)


def write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(canonical_text(value) + "\n", encoding="utf-8")


def write_text(path: Path, value: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(value.rstrip() + "\n", encoding="utf-8")


def read_tar_json(archive: Path, member_name: str) -> dict[str, Any]:
    audit_archive(archive)
    with tarfile.open(archive, mode="r:*") as tar:
        try:
            member = tar.getmember(member_name)
        except KeyError as exc:
            raise RuntimeError(f"required source member missing: {member_name}") from exc
        if not member.isfile():
            raise RuntimeError(f"required source member is not regular: {member_name}")
        stream = tar.extractfile(member)
        if stream is None:
            raise RuntimeError(f"required source member unreadable: {member_name}")
        with stream:
            value = load_json_bytes(stream.read())
    if not isinstance(value, dict):
        raise RuntimeError(f"required source JSON root is not object: {member_name}")
    return value


def verify_inputs(input_dir: Path, design_path: Path) -> tuple[dict[str, Path], list[dict[str, Any]]]:
    paths: dict[str, Path] = {}
    records: list[dict[str, Any]] = []
    for name, expected in EXPECTED_INPUTS.items():
        path = design_path if name == design_path.name else input_dir / name
        if not path.is_file():
            raise RuntimeError(f"required approved input missing: {path}")
        actual = sha256_file(path)
        if actual != expected:
            raise RuntimeError(f"approved input hash mismatch: {name}: {actual}")
        paths[name] = path
        records.append(
            {
                "filename": name,
                "bytes": path.stat().st_size,
                "sha256": actual,
                "verification": "PASS",
            }
        )
    # Metadata-only audits happen before reading any TAR member bytes.
    for name in (
        "G1-A-v2.0.0-candidate.4.tar",
        "G1-B-v2.0.2-candidate.tar.gz",
        "M2_FORMAL_REFROZEN_PATCH_AND_PYTEST_V4.tar.gz",
    ):
        audited = audit_archive(paths[name])
        for record in records:
            if record["filename"] == name:
                record["metadata_only_archive_audit"] = "PASS"
                record["archive_member_count"] = len(audited)
    return paths, records


def source_map() -> dict[str, Any]:
    def source(
        source_id: str,
        issue_uuid: str,
        comment_id: str,
        attachment_id: str | None,
        outer_sha256: str | None,
        role: str,
        hint: str,
    ) -> dict[str, Any]:
        return {
            "source_id": source_id,
            "issue_uuid": issue_uuid,
            "comment_id": comment_id,
            "attachment_id": attachment_id,
            "outer_sha256": outer_sha256,
            "role": role,
            "display_hints": {"label": hint},
        }

    return {
        "schema_version": "m5-source-map/2.0",
        "candidate_version": CANDIDATE_VERSION,
        "identity_key": ["issue_uuid", "comment_id", "attachment_id", "outer_sha256"],
        "display_hints_non_authoritative": True,
        "sources": [
            source("SRC-REPO-BASELINE", "de51e2c0-833a-490f-a886-20a88083e193", "bc29035c-6d15-4622-9c07-69aef0427341", None, None, "READ_ONLY_BASELINE", f"main@{BASELINE_COMMIT}"),
            source("SRC-M0-OWNER-EXIT", "90d11d65-25af-4727-a3a1-a729d54e023c", "3d03b150-4dea-447b-aabb-3ffdc4b72eb6", None, None, "OWNER_EXIT", "M0 PASS_WITH_LIMITATIONS / DONE"),
            source("SRC-M1A-PACKAGE", "dcc8223e-3aa3-4e54-b485-aaf3c44ee86f", "65014e33-78a5-49cb-be3f-aa54aa2299ad", "019ffe39-350c-7337-8537-f6caa2420820", "afabf7b7f8ff7b5c6366949324de1ff82db0d7d45f2aecfb4bd2b7dc2bb59749", "APPROVED_PACKAGE", "G1-A-v2.0.0-candidate.4"),
            source("SRC-M1A-QA", "dcc8223e-3aa3-4e54-b485-aaf3c44ee86f", "4c8ed6ec-6657-4c9b-8590-ce886b08d8d4", None, None, "INDEPENDENT_VERDICT", "G1-A independent ACCEPT"),
            source("SRC-M1A-OWNER-EXIT", "dcc8223e-3aa3-4e54-b485-aaf3c44ee86f", "001a6925-5e52-47d8-bbd1-21b528c36f2a", None, None, "OWNER_EXIT", "M1-A APPROVED / DONE"),
            source("SRC-M1B-CANDIDATE", "cebd505a-5c89-4417-b6d5-345809d9b1f0", "e7bc1917-46fd-468c-96ff-3200911b9657", "019ffe63-e1c6-7e73-a5c1-24aed0b16fb8", "743d73b26186454f77ad4098c4cb05267e28738069b0470a2ad2cc14eb193873", "APPROVED_REFERENCED_PACKAGE", "G1-B-v2.0.2 payload referenced by v2.0.3"),
            source("SRC-M1B-EVIDENCE", "cebd505a-5c89-4417-b6d5-345809d9b1f0", "b07ceb7d-dc64-47e1-a28d-3abdc62f7516", "019ffe71-5e32-7be8-adcf-1fde94b86130", "59e3373d7fb2c9ace4d4712f26f0e1afc740e45a6aae7a8c6fd138ef93f2fb3d", "APPROVED_BUILD_EVIDENCE", "G1-B-v2.0.3 build evidence"),
            source("SRC-M1B-QA", "cebd505a-5c89-4417-b6d5-345809d9b1f0", "b2ebb6a4-2ab2-4fc8-b736-ccbeee8df254", None, None, "INDEPENDENT_VERDICT", "G1-B-v2.0.3 independent ACCEPT"),
            source("SRC-M1B-OWNER-EXIT", "cebd505a-5c89-4417-b6d5-345809d9b1f0", "08f943e2-72ee-44e9-8ba0-0fb00af5ed60", None, None, "OWNER_EXIT", "M1-B APPROVED / DONE"),
            source("SRC-M2-PACKAGE", "c8c8e21a-8d80-447f-82a3-02cfc43fcfa7", "642533e4-b680-4d4f-857c-8a25612ab594", "01a0003c-2d4f-70e2-b0d2-904db4f797a8", "bf3948fa2b47e2f11cb8a2651b3059c6ad61943d9313bd7ff2ab37d76384b671", "APPROVED_PACKAGE", "M2_FORMAL_REFROZEN_PATCH_AND_PYTEST_V4"),
            source("SRC-M2-QA", "c8c8e21a-8d80-447f-82a3-02cfc43fcfa7", "a7fed132-f988-4ae6-98aa-894a17587183", None, None, "INDEPENDENT_VERDICT", "M2 V4 independent ACCEPT"),
            source("SRC-M2-OWNER-EXIT", "c8c8e21a-8d80-447f-82a3-02cfc43fcfa7", "7a62293e-445b-418a-b07d-8163dbaa9962", None, None, "OWNER_EXIT", "M2-FORMAL ACCEPT / DONE"),
            source("SRC-REBASELINE-DESIGN", "de51e2c0-833a-490f-a886-20a88083e193", "bea3fdda-c38f-424e-a549-4c52bd30ad01", "01a000fc-669c-7229-b5f6-615d22074a04", "c0b285b90b1c8f11c480eaeb7869c663e7ba66b74f82f75b52bac046e3a1a542", "ACCEPTED_DESIGN", RULE_VERSION),
            source("SRC-REBASELINE-DESIGN-AUDIT", "de51e2c0-833a-490f-a886-20a88083e193", "87922c60-4dcc-453c-9e43-8fb44b9680a7", None, None, "INDEPENDENT_DESIGN_VERDICT", "Design audit ACCEPT"),
            source("SRC-CANDIDATE1-BUILD-DISPATCH", "de51e2c0-833a-490f-a886-20a88083e193", "bc29035c-6d15-4622-9c07-69aef0427341", None, None, "BUILD_AUTHORITY_HISTORY", "candidate.1 build dispatch"),
            source("SRC-CANDIDATE1-QA-CHANGES", "de51e2c0-833a-490f-a886-20a88083e193", "6f5f3c23-e1c7-4b13-bf7a-2797fa86bb57", None, None, "INDEPENDENT_CANDIDATE_VERDICT", "candidate.1 CHANGES_REQUIRED: source mapping mismatch"),
            source("SRC-CANDIDATE2-BUILD-DISPATCH", "de51e2c0-833a-490f-a886-20a88083e193", "0bad9ac9-c9b6-4a4e-9623-1c6f0157265e", None, None, "BUILD_AUTHORITY", "candidate.2 source-mapping repair dispatch"),
        ],
    }


def legacy_gaps() -> dict[str, Any]:
    names = [
        ("M0_ORIGINAL_CANONICAL_CLOSURE", "SRC-M0-OWNER-EXIT", "source-map.json#SRC-M0-OWNER-EXIT", "OWNER_EXIT", "SOURCE_MAP_ENTRY", "No approved content-bearing M0 package is available; the approved Owner exit is the explicit new-baseline source."),
        ("M1A_ORIGINAL_CANONICAL_CLOSURE", "SRC-M1A-PACKAGE", "source-map.json#SRC-M1A-PACKAGE", "APPROVED_PACKAGE", "SOURCE_MAP_ENTRY", "The content-bearing approved M1-A package is selected; the Owner exit remains stage-verdict evidence only."),
        ("M1B_ORIGINAL_CANONICAL_CLOSURE", "SRC-M1B-EVIDENCE", "source-map.json#SRC-M1B-EVIDENCE", "APPROVED_BUILD_EVIDENCE", "SOURCE_MAP_ENTRY", "The content-bearing M1-B v2.0.3 build evidence is selected; the Owner exit remains stage-verdict evidence only."),
        ("M2_ORIGINAL_CANONICAL_CLOSURE", "SRC-M2-PACKAGE", "source-map.json#SRC-M2-PACKAGE", "APPROVED_PACKAGE", "SOURCE_MAP_ENTRY", "The content-bearing approved M2 V4 package is selected; the Owner exit remains stage-verdict evidence only."),
        ("APPROVED_FIELD_CONTRACT_ORIGINAL", "SRC-M1A-PACKAGE", "policies/carbon-field-contract-candidate.json", "APPROVED_PACKAGE", "DERIVED_CANDIDATE_ARTIFACT", "The new candidate field contract is deterministically derived from the approved M1-A package."),
        ("APPROVED_EVIDENCE_POLICY_ORIGINAL", "SRC-M1A-PACKAGE", "policies/evidence-policy-candidate.json", "APPROVED_PACKAGE", "DERIVED_CANDIDATE_ARTIFACT", "The new candidate evidence policy is deterministically derived from the approved M1-A package."),
        ("APPROVED_PERMISSION_MATRIX_ORIGINAL", "SRC-M1B-CANDIDATE", "policies/permission-matrix-candidate.json", "APPROVED_REFERENCED_PACKAGE", "DERIVED_CANDIDATE_ARTIFACT", "The new candidate permission matrix is deterministically derived from the approved M1-B referenced package."),
    ]
    return {
        "schema_version": "m5-legacy-gaps/2.0",
        "candidate_version": CANDIDATE_VERSION,
        "gap_count": 7,
        "gaps": [
            {
                "gap_id": f"LEGACY-GAP-{index:02d}",
                "category": name,
                "classification": "REBASELINE",
                "legacy_status": "LEGACY_EVIDENCE_UNRECOVERABLE / NOT_SUPPLIED_TO_M5",
                "new_source_id": source_id,
                "new_baseline_path": path,
                "new_source_role": source_role,
                "new_baseline_binding": binding,
                "selection_rationale": rationale,
                "new_baseline_is_continuation": False,
                "boundary": "old bytes/objects are neither reconstructed nor represented as recovered",
            }
            for index, (name, source_id, path, source_role, binding, rationale) in enumerate(names, start=1)
        ],
    }


def source_consistency(root: Path) -> dict[str, Any]:
    source_map_value = load_json_file(root / "source-map.json")
    gaps_value = load_json_file(root / "legacy-gaps.json")
    source_index = {item["source_id"]: item for item in source_map_value["sources"]}
    checks: list[dict[str, Any]] = []
    for gap in gaps_value["gaps"]:
        source_id = gap["new_source_id"]
        source = source_index.get(source_id)
        if source is None:
            raise RuntimeError(f"legacy gap source missing from source-map: {gap['gap_id']}: {source_id}")
        role_matches = source["role"] == gap["new_source_role"]
        binding = gap["new_baseline_binding"]
        if binding == "SOURCE_MAP_ENTRY":
            path_matches = gap["new_baseline_path"] == f"source-map.json#{source_id}"
            target_exists = True
            target_declares_source = True
        elif binding == "DERIVED_CANDIDATE_ARTIFACT":
            target = root / gap["new_baseline_path"]
            target_exists = target.is_file()
            target_value = load_json_file(target) if target_exists else {}
            target_declares_source = source_id in target_value.get("source_ids", [])
            path_matches = target_exists and target_declares_source
        else:
            raise RuntimeError(f"unknown legacy gap binding: {gap['gap_id']}: {binding}")
        status = "PASS" if role_matches and path_matches and target_exists and target_declares_source else "FAIL"
        checks.append(
            {
                "gap_id": gap["gap_id"],
                "new_baseline_path": gap["new_baseline_path"],
                "new_source_id": source_id,
                "declared_source_role": gap["new_source_role"],
                "actual_source_role": source["role"],
                "new_baseline_binding": binding,
                "path_matches_source_id": path_matches,
                "target_exists": target_exists,
                "target_declares_source": target_declares_source,
                "actual_source_map_entry": source,
                "status": status,
            }
        )
    if len(checks) != 7 or any(item["status"] != "PASS" for item in checks):
        raise RuntimeError("legacy gap path/source/role consistency failed")
    return {
        "schema_version": "m5-source-consistency/1.0",
        "candidate_version": CANDIDATE_VERSION,
        "check_scope": "7/7 legacy-gap new baseline path, source ID, role, and actual source-map entry",
        "checked_count": 7,
        "passed_count": 7,
        "status": "PASS",
        "checks": checks,
    }


def stage_verdicts() -> dict[str, Any]:
    rows = [
        ("M0", "PASS_WITH_LIMITATIONS / DONE", ["SRC-M0-OWNER-EXIT"]),
        ("M1-A", "APPROVED / DONE", ["SRC-M1A-QA", "SRC-M1A-OWNER-EXIT"]),
        ("M1-B", "APPROVED / DONE", ["SRC-M1B-QA", "SRC-M1B-OWNER-EXIT"]),
        ("M2-PREP", "DONE", ["SRC-M2-PACKAGE", "SRC-M2-OWNER-EXIT"]),
        ("M2-FORMAL", "ACCEPT / DONE", ["SRC-M2-QA", "SRC-M2-OWNER-EXIT"]),
        ("M5-CLOSURE-CANDIDATE", "PENDING_INDEPENDENT_QA / NOT_EFFECTIVE", ["SRC-CANDIDATE1-QA-CHANGES", "SRC-CANDIDATE2-BUILD-DISPATCH"]),
        ("M6", "BLOCKED_BY_M5", ["SRC-CANDIDATE2-BUILD-DISPATCH"]),
    ]
    return {
        "schema_version": "m5-stage-verdicts/2.0",
        "stages": [{"stage": stage, "verdict": verdict, "source_ids": sources} for stage, verdict, sources in rows],
        "candidate_verdict_enum": ["ACCEPT", "CHANGES_REQUIRED", "BLOCKED"],
    }


def field_contract_policy(g1a_rules: dict[str, Any]) -> dict[str, Any]:
    contract = g1a_rules["field_contract"]
    return {
        "schema_version": "m5-new-field-contract-candidate/1.0",
        "policy_version": f"{CANDIDATE_VERSION}/field-contract/1.0.0",
        "status": "NEW_BASELINE_CANDIDATE / PENDING_INDEPENDENT_QA / NOT_EFFECTIVE",
        "new_baseline_is_continuation": False,
        "source_ids": ["SRC-M1A-PACKAGE", "SRC-M1A-QA", "SRC-M1A-OWNER-EXIT"],
        "source_outer_sha256": EXPECTED_INPUTS["G1-A-v2.0.0-candidate.4.tar"],
        "source_rule_id": contract["rule_id"],
        "candidate_status_enum": contract["candidate_status_enum"],
        "confirmation_status_enum": contract["confirmation_status_enum"],
        "formal_write_allowed_for_ai": contract["formal_write_allowed_for_ai"],
        "confirmation_required_for_all_fields": contract["confirmation_required_for_all_fields"],
        "confirmation_binding_required": contract["confirmation_binding_required"],
        "fields": contract["fields"],
        "formula_type_unchanged": True,
        "factor_source_priority_unchanged": True,
        "business_boundary_unchanged": True,
        "result_meaning_unchanged": True,
    }


def evidence_policy(g1a_rules: dict[str, Any]) -> dict[str, Any]:
    evidence = g1a_rules["evidence_location"]
    return {
        "schema_version": "m5-new-evidence-policy-candidate/1.0",
        "policy_version": f"{CANDIDATE_VERSION}/evidence-policy/1.0.0",
        "status": "NEW_BASELINE_CANDIDATE / PENDING_INDEPENDENT_QA / NOT_EFFECTIVE",
        "new_baseline_is_continuation": False,
        "source_ids": ["SRC-M1A-PACKAGE", "SRC-M1A-QA", "SRC-M2-PACKAGE", "SRC-M2-QA"],
        "reference_required": evidence["reference_required"],
        "quote_match": evidence["quote_match"],
        "document_binding": evidence["document_binding"],
        "missing_value_must_be_null": evidence["missing_value_must_be_null"],
        "source_identity_required": ["issue_uuid", "comment_id", "attachment_id", "outer_sha256"],
        "default_on_mismatch": "FAIL_CLOSED",
        "truth_minimum_disclosure": True,
        "independent_review_required": True,
        "failed_candidate_retention": "READ_ONLY_PERMANENT_WITH_REJECTED_OR_WITHDRAWN_NOT_EFFECTIVE_STATUS",
        "unregistered_or_orphan_reference_action": "REJECT",
        "hash_mismatch_action": "REJECT",
        "legacy_object_reconstruction": "FORBIDDEN",
    }


def permission_policy(g1b_matrix: dict[str, Any]) -> dict[str, Any]:
    return {
        "schema_version": "m5-new-permission-matrix-candidate/1.0",
        "policy_version": f"{CANDIDATE_VERSION}/permission-matrix/1.0.0",
        "status": "NEW_BASELINE_CANDIDATE / PENDING_INDEPENDENT_QA / NOT_EFFECTIVE",
        "new_baseline_is_continuation": False,
        "source_ids": ["SRC-M1B-CANDIDATE", "SRC-M1B-QA", "SRC-M1B-OWNER-EXIT"],
        "default": "DENY",
        "formal_write_allowed": False,
        "publish_allowed": False,
        "permissions_granted_by_candidate": [],
        "globally_forbidden_actions": [
            "real_data_read", "credential_read", "production_access", "remote_write",
            "publish", "competition_submission", "external_llm_call",
        ],
        "roles": {
            "builder": {"allow": ["new_closure_candidate_metadata"], "deny": ["independent_qa_verdict", "owner_freeze", "restricted_truth_payload"]},
            "independent_qa": {"allow": ["candidate_archive", "detached_manifest", "approved_opaque_source_references"], "deny": ["candidate_mutation", "owner_freeze"]},
            "owner": {"allow": ["freeze_decision_after_independent_qa_accept"], "deny": ["builder_self_approval"]},
            "developer": g1b_matrix["roles"]["developer"],
            "qa": g1b_matrix["roles"]["qa"],
            "researcher": g1b_matrix["roles"]["researcher"],
        },
        "holdout_adversarial_truth_rule": g1b_matrix["truth_exposure_rule"],
        "external_iam_or_worm_claimed": False,
    }


def replacement_log() -> dict[str, Any]:
    gap_records = [
        {
            "record_id": f"RPL-{index:02d}",
            "legacy_gap_id": f"LEGACY-GAP-{index:02d}",
            "resolution": "NEW_VERSIONED_BASELINE_CANDIDATE_WITH_LEGACY_GAP_RETAINED",
            "new_baseline_is_continuation": False,
            "conflict_status": "RESOLVED_FAIL_CLOSED",
        }
        for index in range(1, 8)
    ]
    conflict_records = [
        {
            "record_id": "RPL-08",
            "legacy_gap_id": None,
            "resolution": "M2 embedded historical G1-B freeze record is non-canonical; later G1-B-v2.0.3 QA and Owner exit govern the new baseline",
            "winning_source_ids": ["SRC-M1B-QA", "SRC-M1B-OWNER-EXIT"],
            "retained_conflicting_source": "SRC-M2-PACKAGE",
            "new_baseline_is_continuation": False,
            "conflict_status": "RESOLVED_BY_LATER_VERSIONED_OWNER_RECORD_WITH_HISTORY_RETAINED",
        },
        {
            "record_id": "RPL-09",
            "legacy_gap_id": None,
            "resolution": "Earlier conditional M2 exit statement is superseded by the later M2 owner recovery exit",
            "winning_source_ids": ["SRC-M2-QA", "SRC-M2-OWNER-EXIT"],
            "retained_conflicting_comment_id": "5f47ecdc-efb8-4e01-9e0b-4203667dc818",
            "new_baseline_is_continuation": False,
            "conflict_status": "RESOLVED_BY_LATER_OWNER_EXIT_WITH_HISTORY_RETAINED",
        },
    ]
    return {
        "schema_version": "m5-replacement-conflict-log/2.0",
        "candidate_version": CANDIDATE_VERSION,
        "unresolved_conflict_count": 0,
        "records": gap_records + conflict_records,
    }


def review_verdict() -> dict[str, Any]:
    return {
        "schema_version": "m5-review-verdict/2.0",
        "design_version": RULE_VERSION,
        "design_review_verdict": "ACCEPT",
        "design_review_source_id": "SRC-REBASELINE-DESIGN-AUDIT",
        "candidate_version": CANDIDATE_VERSION,
        "candidate_review_verdict": "PENDING_INDEPENDENT_QA",
        "independent_candidate_reviewer_id": "38f6e4c3-7427-4703-bb35-9f28c5609e5c",
        "builder_id": "1ddf3b86-2ad0-4909-a322-db4aea2d79ed",
        "self_review_allowed": False,
        "qa_required_checks": [
            "outer_and_member_hashes", "path_traversal_negative", "symlink_negative",
            "unregistered_file_negative", "three_fresh_root_replays", "canonical_source_identities",
            "legacy_gap_source_path_role_consistency_7_of_7", "permissions_and_stage_boundaries",
        ],
        "repair_source_ids": ["SRC-CANDIDATE1-QA-CHANGES", "SRC-CANDIDATE2-BUILD-DISPATCH"],
    }


def owner_exit() -> dict[str, Any]:
    return {
        "schema_version": "m5-owner-exit/2.0",
        "historical_owner_exits": [
            {"stage": "M0", "source_id": "SRC-M0-OWNER-EXIT", "verdict": "PASS_WITH_LIMITATIONS / DONE"},
            {"stage": "M1-A", "source_id": "SRC-M1A-OWNER-EXIT", "verdict": "APPROVED / DONE"},
            {"stage": "M1-B", "source_id": "SRC-M1B-OWNER-EXIT", "verdict": "APPROVED / DONE"},
            {"stage": "M2-FORMAL", "source_id": "SRC-M2-OWNER-EXIT", "verdict": "ACCEPT / DONE"},
        ],
        "candidate_owner_exit": "PENDING_INDEPENDENT_QA_ACCEPT",
        "automatic_freeze_conditions": [
            "independent QA verdict equals ACCEPT",
            "outer and per-member SHA-256 all match",
            "three fresh-root semantic replay digests are identical",
            "all hostile-archive controls reject without out-of-root writes or entrypoint execution",
            "no unresolved source, permission, verdict, hash, legacy-gap, or stage-boundary conflict",
        ],
        "self_approval_allowed": False,
        "decision_maker": "project Owner proxy",
    }


def limitations() -> dict[str, Any]:
    return {
        "schema_version": "m5-limitations-matrix/2.0",
        "execution_mode": EXECUTION_MODE,
        "m5_status": "CHANGES_REQUIRED",
        "m6_status": "BLOCKED_BY_M5",
        "truth_payload_included": False,
        "source_payloads_embedded": False,
        "hash_verification_kind": "SHA-256_CONTENT_INTEGRITY_NO_ASYMMETRIC_SIGNATURE",
        "limitations": [
            {"id": "LIM-01", "statement": "Seven original canonical/policy objects remain unrecoverable and are not supplied to M5.", "effect": "New baseline only; no legacy recovery claim."},
            {"id": "LIM-02", "statement": "Restricted Holdout/Adversarial truth bytes are not embedded.", "effect": "QA consumes only approved opaque platform references under its access boundary."},
            {"id": "LIM-03", "statement": "M0 retains accepted environment and repository-access limitations.", "effect": "No remote write, push, PR, or production capability is inferred."},
            {"id": "LIM-04", "statement": "M2 evidence is limited to static/static-v1, synthetic inputs, and virtual Truth controls.", "effect": "No external model or real-data qualification."},
            {"id": "LIM-05", "statement": "Candidate has not received independent QA or Owner freeze.", "effect": "NOT_EFFECTIVE; M5 remains CHANGES_REQUIRED and M6 blocked."},
            {"id": "LIM-06", "statement": "Integrity uses layered detached and embedded SHA-256 manifests.", "effect": "All archive members are hashed without an impossible self-hash cycle; no identity/authenticity signature is claimed."},
        ],
        "rollback": {
            "delete_allowed": ["temporary_download_copy", "temporary_safe_extract_root", "temporary_run_workdir"],
            "delete_forbidden": ["submitted_candidate_archive", "submitted_detached_manifest", "submitted_logs", "review_verdict", "legacy_gap_records"],
            "failed_candidate_status": "REJECTED_OR_WITHDRAWN / NOT_EFFECTIVE / READ_ONLY_RETAINED",
        },
    }


def build_record(input_records: list[dict[str, Any]], builder_dir: Path) -> dict[str, Any]:
    return {
        "schema_version": "m5-build-record/2.0",
        "candidate_version": CANDIDATE_VERSION,
        "generator_version": GENERATOR_VERSION,
        "rule_version": RULE_VERSION,
        "random_seed": RANDOM_SEED,
        "randomness_used": False,
        "source_baseline": {"repository": BASELINE_REPOSITORY, "ref": "main", "commit": BASELINE_COMMIT, "read_only": True},
        "input_verification": input_records,
        "builder_source_hashes": {
            name: sha256_file(builder_dir / name)
            for name in ("build_candidate.py", "safe_extract.py", "canonicalize_json.py", "replay.py", "run_negative_tests.py", "verify_candidate.py")
        },
        "responsibility": {
            "builder": "synthetic data and benchmark engineer",
            "independent_reviewer": "model evaluation and QA engineer",
            "decision_maker": "project Owner proxy",
            "role_separation": True,
        },
        "external_actions": {"remote_write": False, "publish": False, "competition_submission": False, "external_llm": False},
        "predecessor_candidate": {
            "candidate_version": "M5_UPSTREAM_EVIDENCE_CLOSURE_V2.0.0-candidate.1",
            "archive_sha256": "6abbc633de519d1e2501db241c41712d92d1f73518dc50eadc79db99869b129b",
            "qa_source_id": "SRC-CANDIDATE1-QA-CHANGES",
            "status": "CHANGES_REQUIRED / NOT_EFFECTIVE / READ_ONLY_RETAINED",
        },
    }


def read_semantic(root: Path) -> dict[str, Any]:
    return {path: load_json_file(root / path) for path in SEMANTIC_DOCUMENTS}


def archive_members(root: Path, include_manifest: bool) -> list[dict[str, Any]]:
    members: list[dict[str, Any]] = []
    for path in sorted(item for item in root.rglob("*") if item.is_file()):
        relative = path.relative_to(root).as_posix()
        if not include_manifest and relative == "manifest.json":
            continue
        members.append({"path": relative, "type": "file", "size": path.stat().st_size, "sha256": sha256_file(path)})
    return members


def deterministic_archive(root: Path, target: Path) -> None:
    with target.open("wb") as raw:
        with gzip.GzipFile(filename="", mode="wb", fileobj=raw, mtime=0, compresslevel=9) as zipped:
            with tarfile.open(fileobj=zipped, mode="w", format=tarfile.PAX_FORMAT) as tar:
                for path in sorted(item for item in root.rglob("*") if item.is_file()):
                    relative = f"{ROOT_NAME}/{path.relative_to(root).as_posix()}"
                    data = path.read_bytes()
                    info = tarfile.TarInfo(relative)
                    info.type = tarfile.REGTYPE
                    info.mode = 0o600
                    info.uid = 0
                    info.gid = 0
                    info.uname = ""
                    info.gname = ""
                    info.mtime = 0
                    info.size = len(data)
                    tar.addfile(info, io.BytesIO(data))


def readme_text(semantic_digest: str) -> str:
    return f"""# {CANDIDATE_VERSION}

`NEW_BASELINE / NOT_A_CONTINUATION`

`{EXECUTION_MODE}`

This closure is a new candidate baseline. It does not recover or replace the
bytes of the seven legacy gaps. It freezes only structured source identities,
outer hashes, new policy candidates, stage verdict mappings, conflict
resolution records, replay controls, and strict permission/stage boundaries.

Restricted source payloads and Holdout/Adversarial truth are not embedded.
Their approved OPC attachment UUIDs and outer SHA-256 values are recorded in
`source-map.json`; display labels are non-authoritative.

## Verify safely

Use the separately supplied byte-identical `safe_extract.py` bootstrap before
extracting anything:

```text
python3 safe_extract.py \\
  --archive {CANDIDATE_VERSION}.tar.gz \\
  --detached-manifest {CANDIDATE_VERSION}.archive-manifest.json \\
  --destination NEW_EMPTY_ROOT \\
  --execute
```

The verifier checks the outer hash, audits TAR metadata without landing,
rejects unsafe member types/paths/collisions, extracts regular files with
no-follow semantics, verifies the detached and embedded complete member sets
and every file hash, and only then executes the registered hash-matched
`replay.py` under a minimal environment.

Expected canonical semantic SHA-256: `{semantic_digest}`.

The six and only six runtime comparison exclusions are exact top-level JSON
pointers: `/generated_at`, `/run_started_at`, `/run_finished_at`,
`/duration_ms`, `/temporary_workdir`, `/process_id`. No wildcard, prefix, or
recursive exclusion exists.

## Candidate state

Independent candidate QA is pending. M5 remains `CHANGES_REQUIRED`; M6 remains
`BLOCKED_BY_M5`. This archive grants no production, real-data, credential,
remote-write, publish, external-LLM, or competition-submission permission.

Rollback removes only reproducible temporary copies. Any submitted candidate,
including a rejected or withdrawn version, must remain read-only with its
archive, hashes, manifests, logs, and verdict.
"""


def build(args: argparse.Namespace) -> dict[str, Any]:
    builder_dir = Path(__file__).resolve().parent
    inputs, input_records = verify_inputs(args.input_dir, args.design)
    g1a_rules = read_tar_json(inputs["G1-A-v2.0.0-candidate.4.tar"], "g1-a-v2-candidate-4/rules.json")
    g1b_matrix = read_tar_json(inputs["G1-B-v2.0.2-candidate.tar.gz"], "G1-B-v2.0.2/access/authorization-matrix.json")
    g1b_evidence = load_json_file(inputs["G1-B-v2.0.3-build-evidence.json"])
    if g1b_evidence.get("evidence_version") != "G1-B-v2.0.3-build-evidence/1.0":
        raise RuntimeError("unexpected G1-B evidence version")

    args.output_dir.mkdir(parents=True, exist_ok=True)
    root = args.output_dir / ROOT_NAME
    archive = args.output_dir / f"{ROOT_NAME}.tar.gz"
    detached = args.output_dir / f"{ROOT_NAME}.archive-manifest.json"
    detached_sums = args.output_dir / f"{ROOT_NAME}.detached-SHA256SUMS"
    bootstrap = args.output_dir / "safe_extract.py"
    for path in (root, archive, detached, detached_sums, bootstrap):
        if path.exists():
            if not args.replace:
                raise RuntimeError(f"output exists; pass --replace: {path}")
            if path.is_dir():
                shutil.rmtree(path)
            else:
                path.unlink()
    root.mkdir(parents=True)

    (root / "tools").mkdir()
    for name in ("safe_extract.py", "canonicalize_json.py", "build_candidate.py", "run_negative_tests.py", "verify_candidate.py"):
        shutil.copy2(builder_dir / name, root / "tools" / name)
    shutil.copy2(builder_dir / "replay.py", root / "replay.py")
    shutil.copy2(builder_dir / "safe_extract.py", bootstrap)

    write_json(root / "source-map.json", source_map())
    write_json(root / "legacy-gaps.json", legacy_gaps())
    write_json(root / "stage-verdicts.json", stage_verdicts())
    write_json(root / "policies/carbon-field-contract-candidate.json", field_contract_policy(g1a_rules))
    write_json(root / "policies/evidence-policy-candidate.json", evidence_policy(g1a_rules))
    write_json(root / "policies/permission-matrix-candidate.json", permission_policy(g1b_matrix))
    write_json(root / "source-consistency.json", source_consistency(root))
    write_json(root / "replacement-and-conflict-log.json", replacement_log())
    write_json(root / "review-verdict.json", review_verdict())
    write_json(root / "owner-exit.json", owner_exit())
    write_json(root / "limitations-matrix.json", limitations())
    write_json(root / "build-record.json", build_record(input_records, builder_dir))

    semantic_digest = canonical_sha256(read_semantic(root))
    negative_results = run_tests()
    for result in negative_results:
        write_json(root / f"tests/{result['test_id'].lower()}.json", result)
    write_json(root / "tests/negative-summary.json", {"status": "PASS", "count": 3, "tests": [item["test_id"] for item in negative_results]})

    # These three records are actual deterministic builder-directory semantic
    # replays. Final archive extraction/replay is performed after packaging and
    # retained as detached logs, because an archive cannot contain records of a
    # later validation of its own final outer hash without changing that hash.
    round_digests = [canonical_sha256(read_semantic(root)) for _ in range(3)]
    if len(set(round_digests)) != 1 or round_digests[0] != semantic_digest:
        raise RuntimeError("builder-directory replay mismatch")
    for index, digest in enumerate(round_digests, start=1):
        write_json(
            root / f"replay/builder-round-{index}.json",
            {
                "run_id": f"BUILDER-ROUND-{index}",
                "fresh_semantic_load": True,
                "exit_code": 0,
                "semantic_sha256": digest,
                "status": "PASS",
            },
        )
    write_json(
        root / "replay/builder-summary.json",
        {
            "rounds": 3,
            "semantic_consistency_percent": 100,
            "semantic_sha256": semantic_digest,
            "status": "PASS",
            "final_archive_fresh_root_replay": "REQUIRED_AND_RETAINED_DETACHED",
        },
    )
    write_text(root / "README.md", readme_text(semantic_digest))

    checksum_lines = []
    for item in archive_members(root, include_manifest=False):
        if item["path"] == "SHA256SUMS":
            continue
        checksum_lines.append(f"{item['sha256']}  {item['path']}")
    write_text(root / "SHA256SUMS", "\n".join(checksum_lines))

    tools = {
        "safe_extractor": {"path": "tools/safe_extract.py", "version": SAFE_EXTRACT_VERSION, "sha256": sha256_file(root / "tools/safe_extract.py")},
        "canonicalizer": {"path": "tools/canonicalize_json.py", "version": "m5-canonical-json/1.0.0", "sha256": sha256_file(root / "tools/canonicalize_json.py")},
        "replay": {"path": "replay.py", "version": "m5-closure-replay/2.0.0-candidate.2", "sha256": sha256_file(root / "replay.py")},
        "release_verifier": {"path": "tools/verify_candidate.py", "version": "m5-candidate-release-verifier/1.0.0", "sha256": sha256_file(root / "tools/verify_candidate.py")},
    }
    members_without_manifest = archive_members(root, include_manifest=False)
    manifest = {
        "schema_version": "m5-closure-manifest/2.0",
        "candidate_version": CANDIDATE_VERSION,
        "status": "NEW_BASELINE / NOT_A_CONTINUATION / PENDING_INDEPENDENT_QA / NOT_EFFECTIVE",
        "execution_mode": EXECUTION_MODE,
        "generator_version": GENERATOR_VERSION,
        "rule_version": RULE_VERSION,
        "random_seed": RANDOM_SEED,
        "source_baseline": {"repository": BASELINE_REPOSITORY, "ref": "main", "commit": BASELINE_COMMIT},
        "entrypoint": "replay.py",
        "self": {"path": "manifest.json", "type": "file", "sha256_source": "detached_archive_manifest"},
        "member_count": len(members_without_manifest) + 1,
        "members": members_without_manifest,
        "tools": tools,
        "canonical_json": {
            "version": "m5-canonical-json/1.0.0",
            "encoding": "UTF-8",
            "object_key_order": "Unicode code point ascending",
            "array_order": "business order; no set arrays declared in this closure",
            "number_format": "integers decimal; non-integers normalized fixed-point Decimal; NaN/Infinity forbidden",
            "duplicate_keys": "forbidden",
        },
        "runtime_exclusion_allowlist": [
            "/generated_at", "/run_started_at", "/run_finished_at", "/duration_ms", "/temporary_workdir", "/process_id",
        ],
        "expected_semantic_sha256": semantic_digest,
    }
    write_json(root / "manifest.json", manifest)

    deterministic_archive(root, archive)
    outer_sha = sha256_file(archive)
    external_members = [
        {"path": f"{ROOT_NAME}/{item['path']}", "type": "file", "size": item["size"], "sha256": item["sha256"]}
        for item in archive_members(root, include_manifest=True)
    ]
    detached_value = {
        "schema_version": "m5-detached-archive-manifest/1.0",
        "candidate_version": CANDIDATE_VERSION,
        "archive_sha256": outer_sha,
        "entry_root": ROOT_NAME,
        "member_count": len(external_members),
        "members": external_members,
    }
    write_json(detached, detached_value)
    write_text(
        detached_sums,
        f"{outer_sha}  {archive.name}\n{sha256_file(detached)}  {detached.name}\n{sha256_file(bootstrap)}  {bootstrap.name}",
    )
    return {
        "candidate_version": CANDIDATE_VERSION,
        "archive": str(archive),
        "archive_sha256": outer_sha,
        "detached_manifest": str(detached),
        "detached_manifest_sha256": sha256_file(detached),
        "safe_extract": str(bootstrap),
        "safe_extract_sha256": sha256_file(bootstrap),
        "member_count": len(external_members),
        "semantic_sha256": semantic_digest,
        "negative_tests": "3/3 PASS",
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input-dir", type=Path, required=True)
    parser.add_argument("--design", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--replace", action="store_true")
    args = parser.parse_args()
    result = build(args)
    print(json.dumps(result, ensure_ascii=False, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
