#!/usr/bin/env python3
"""Deterministic JSON canonicalization for the M5 evidence closure.

Version: m5-canonical-json/1.0.0

The implementation deliberately supports a narrow, auditable number model:
JSON integers remain integers; non-integers are parsed as Decimal and emitted
in normalized fixed-point form. NaN and Infinity are rejected by the parser.
Object duplicate keys are rejected. Arrays preserve order; callers must sort
business-set arrays before invoking this module.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from decimal import Decimal
from pathlib import Path
from typing import Any, Iterable

VERSION = "m5-canonical-json/1.0.0"
RUNTIME_EXCLUSION_ALLOWLIST = (
    "/generated_at",
    "/run_started_at",
    "/run_finished_at",
    "/duration_ms",
    "/temporary_workdir",
    "/process_id",
)


class CanonicalizationError(ValueError):
    """Raised when input cannot be represented under the frozen rules."""


def _reject_duplicate_keys(pairs: Iterable[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise CanonicalizationError(f"duplicate object key: {key!r}")
        result[key] = value
    return result


def load_json_bytes(data: bytes) -> Any:
    try:
        text = data.decode("utf-8", errors="strict")
    except UnicodeDecodeError as exc:
        raise CanonicalizationError("input is not strict UTF-8") from exc
    try:
        return json.loads(
            text,
            object_pairs_hook=_reject_duplicate_keys,
            parse_float=Decimal,
            parse_constant=lambda value: (_ for _ in ()).throw(
                CanonicalizationError(f"non-finite number forbidden: {value}")
            ),
        )
    except json.JSONDecodeError as exc:
        raise CanonicalizationError(str(exc)) from exc


def load_json_file(path: Path) -> Any:
    return load_json_bytes(path.read_bytes())


def _decimal_text(value: Decimal) -> str:
    if not value.is_finite():
        raise CanonicalizationError("non-finite decimal forbidden")
    if value == 0:
        return "0"
    normalized = value.normalize()
    text = format(normalized, "f")
    if "." in text:
        text = text.rstrip("0").rstrip(".")
    if text.startswith("-0") and Decimal(text) == 0:
        return "0"
    return text


def canonical_text(value: Any) -> str:
    if value is None:
        return "null"
    if value is True:
        return "true"
    if value is False:
        return "false"
    if isinstance(value, int):
        return str(value)
    if isinstance(value, Decimal):
        return _decimal_text(value)
    if isinstance(value, float):
        raise CanonicalizationError("binary float forbidden")
    if isinstance(value, str):
        return json.dumps(value, ensure_ascii=False, separators=(",", ":"))
    if isinstance(value, list):
        return "[" + ",".join(canonical_text(item) for item in value) + "]"
    if isinstance(value, dict):
        if not all(isinstance(key, str) for key in value):
            raise CanonicalizationError("object keys must be strings")
        items = []
        for key in sorted(value.keys()):
            items.append(
                json.dumps(key, ensure_ascii=False, separators=(",", ":"))
                + ":"
                + canonical_text(value[key])
            )
        return "{" + ",".join(items) + "}"
    raise CanonicalizationError(f"unsupported JSON value type: {type(value).__name__}")


def canonical_bytes(value: Any) -> bytes:
    return canonical_text(value).encode("utf-8")


def canonical_sha256(value: Any) -> str:
    return hashlib.sha256(canonical_bytes(value)).hexdigest()


def exclude_runtime_fields(value: Any, pointers: Iterable[str]) -> Any:
    requested = tuple(pointers)
    unknown = sorted(set(requested) - set(RUNTIME_EXCLUSION_ALLOWLIST))
    if unknown:
        raise CanonicalizationError(f"runtime exclusion not allowed: {unknown}")
    if not isinstance(value, dict):
        raise CanonicalizationError("runtime exclusions require a top-level object")
    result = dict(value)
    for pointer in requested:
        # Frozen v1 policy permits exact top-level JSON pointers only. There is
        # intentionally no wildcard, prefix, or recursive traversal support.
        result.pop(pointer[1:], None)
    return result


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("json_file", type=Path)
    parser.add_argument("--sha256", action="store_true")
    parser.add_argument("--exclude-pointer", action="append", default=[])
    args = parser.parse_args()

    value = load_json_file(args.json_file)
    if args.exclude_pointer:
        value = exclude_runtime_fields(value, args.exclude_pointer)
    if args.sha256:
        print(canonical_sha256(value))
    else:
        print(canonical_text(value))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
